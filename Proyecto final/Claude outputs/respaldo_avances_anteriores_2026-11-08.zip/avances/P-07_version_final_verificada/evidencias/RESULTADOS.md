# Resultados — P-07_version_final_verificada

Generado: 2026-11-04T15:08:25 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 98 | 0 | 0 | 0 | 82 % | cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz). Gesto activo durante la medición: ColorPenRecognition.

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0748 | 0.107 | 0.273 | 0 |
| GestureCamera | 0.1482 | 0.212 | 1.301 | 0 |
| ImageProcessor | 0.0045 | 0.006 | 0.077 | 0 |
| ColorPenRecognition | 0.0928 | 0.703 | 1.038 | 0 |
| HandSkinRecognition | 0.002 | 0.004 | 0.04 | 0 |
| MouseRecognition | 0.0024 | 0.003 | 0.09 | 0 |
| EyeTrackerMock | 0.0083 | 0.011 | 0.083 | 0 |
| SpeechProvider | 0.0024 | 0.003 | 0.086 | 0 |
| GazeSession | 0.0044 | 0.004 | 0.272 | 0 |
| ConsistencyProvider | 0.0084 | 0.01 | 0.125 | 0 |
| **Ciclo completo** | 0.3892 | 1.0343 | 2.2615 | 0 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| GestureCamera | initialized |  |
| ImageProcessor | initialized |  |
| ColorPenRecognition | initialized |  |
| HandSkinRecognition | initialized |  |
| MouseRecognition | initialized |  |
| EyeTracker-GazePoint | disabled |  |
| EyeTracker-EyeTribe | disabled |  |
| EyeTracker-GazeCloud | disabled |  |
| EyeTrackerMock | initialized |  |
| GazeSession | initialized |  |
| ConsistencyProvider | initialized |  |
| LLM-Gemini | initialization_failed | initialize() retornó False. |
| SpeechProvider | initialized |  |

## Demostración de consistencia papel ↔ PDF (demos/demo_consistencia.py)

| Llamada (por OrchestratorCore.invoke) | Correcta | Latencia (ms) | Resultado |
|---|---|---|---|
| search_text | sí | 5.036 | [2] |
| add_highlight | sí | 2.56 | True |
| add_bookmark | sí | 2.315 | None |
| sync_bookmark_from_frame | sí | 3.862 | True |
| sync_comments_from_frame | sí | 2.96 | 1 |
| sync_figures_from_frame | sí | 3.51 | 2 |
| get_bookmarks | sí | 0.189 | ['Introducción Pag.1', 'Marcador físico página 2 Pag.2'] |
| get_comments | sí | 0.361 | [{'content': 'Comentario físico 1 (pág. 2)', 'page': 2, 'x': |
| get_figures | sí | 0.124 | {'rectangulos': [{'x': 234.327731092437, 'y': 108.2155603694 |
| search_text | sí | 0.002 | [] |

Al reabrir el PDF guardado: anotaciones por página [1, 1, 2] (esperado [1, 1, 2]), 2 marcadores (esperado 2), PDF reparado al abrir: False. **Se conservan todos los cambios.**

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
- capturas/03_gesture_mano.png
- capturas/03_gesture_lapiz.png
- capturas/04_eye.png
- capturas/05_web.png
- capturas/06_interactions.png
- capturas/10_proyeccion.png
