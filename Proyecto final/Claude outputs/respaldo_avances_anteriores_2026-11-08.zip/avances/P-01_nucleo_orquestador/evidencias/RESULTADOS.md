# Resultados — P-01_nucleo_orquestador

Generado: 2026-11-04T15:07:18 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 34 | 0 | 0 | 0 | 81 % | cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz).

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0731 | 0.103 | 0.291 | 0 |
| FrameStatistics | 0.5643 | 0.804 | 1.612 | 0 |
| EyeTrackerMock | 0.0094 | 0.013 | 0.061 | 0 |
| FaultInjection | 0.0148 | 0.121 | 0.191 | 0 |
| CycleSummary | 0.0102 | 0.012 | 0.094 | 0 |
| **Ciclo completo** | 0.6991 | 0.9621 | 1.7727 | 0 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| FrameStatistics | initialized |  |
| EyeTrackerMock | initialized |  |
| FaultInjection | initialized |  |
| PluginInexistente | load_failed | El plugin no se pudo cargar; revisa el log del PluginLoader. |
| CycleSummary | initialized |  |
