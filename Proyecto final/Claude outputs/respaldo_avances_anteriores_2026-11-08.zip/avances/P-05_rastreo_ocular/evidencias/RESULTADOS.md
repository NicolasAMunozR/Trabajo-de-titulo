# Resultados — P-05_rastreo_ocular

Generado: 2026-11-04T15:07:51 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 88 | 0 | 0 | 1 | 79 % | no cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz). Gesto activo durante la medición: ColorPenRecognition.

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0873 | 0.119 | 2.032 | 0 |
| GestureCamera | 0.1841 | 0.263 | 2.259 | 0 |
| ImageProcessor | 0.005 | 0.006 | 0.073 | 0 |
| ColorPenRecognition | 0.1052 | 0.789 | 1.394 | 0 |
| HandSkinRecognition | 0.0021 | 0.004 | 0.052 | 0 |
| MouseRecognition | 0.0025 | 0.003 | 0.087 | 0 |
| EyeTrackerMock | 0.0085 | 0.015 | 0.046 | 0 |
| GazeSession | 0.004 | 0.005 | 0.052 | 0 |
| ConsistencyProvider | 0.0081 | 0.011 | 0.079 | 0 |
| **Ciclo completo** | 0.4494 | 1.1735 | 2.5246 | 0 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| GestureCamera | initialized |  |
| ImageProcessor | initialized |  |
| ColorPenRecognition | initialized |  |
| HandSkinRecognition | initialized |  |
| MouseRecognition | initialized |  |
| EyeTracker-GazePoint | disabled |  |
| EyeTracker-EyeTribe | disabled |  |
| EyeTracker-GazeCloud | disabled |  |
| EyeTrackerMock | initialized |  |
| GazeSession | initialized |  |
| ConsistencyProvider | initialized |  |

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
- capturas/03_gesture_mano.png
- capturas/03_gesture_lapiz.png
- capturas/04_eye.png
