# Resultados — P-03_reconocimiento_texto_e_interfaz

Generado: 2026-11-04T15:07:30 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 60 | 0 | 0 | 0 | 76 % | no cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz).

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0703 | 0.096 | 0.146 | 0 |
| ImageProcessor | 0.0038 | 0.005 | 0.014 | 0 |
| ConsistencyProvider | 0.0084 | 0.009 | 0.487 | 0 |
| **Ciclo completo** | 0.1055 | 0.1387 | 0.5872 | 0 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| ImageProcessor | initialized |  |
| ConsistencyProvider | initialized |  |

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
