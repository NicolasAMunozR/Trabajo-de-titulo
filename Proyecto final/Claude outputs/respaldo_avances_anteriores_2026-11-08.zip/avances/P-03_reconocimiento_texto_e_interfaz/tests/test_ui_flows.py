"""Pruebas de la interfaz (Qt offscreen) del avance P-03: fidelidad del layout y flujos de los
módulos ya integrados. Las pruebas de la pantalla de proyección y de los servicios LLM llegan en P-06."""
import json

import pytest
from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest

from ui.form_builder import LAYOUTS, build_form

FORMS = ['MenuSettings', 'TextRecognitionSettings', 'PageDetectionSettings', 'AlertBox', 'LoadingBox']
PAGES = ['text', 'page']


def _nodes(nodes):
    for node in nodes:
        yield node
        yield from _nodes(node.get("children", []))


@pytest.mark.parametrize("name", FORMS)
def test_every_original_control_is_rebuilt_at_its_original_geometry(qapp, name):
    from PySide6.QtWidgets import QWidget
    data = json.loads((LAYOUTS / f"{name}.json").read_text(encoding="utf-8"))
    root = QWidget()
    form = build_form(name, root)
    for node in _nodes(data["controls"]):
        if node["type"] in ("Container",):
            continue
        widget = form.controls[node["name"]]
        x, y = node["props"].get("Location", [0, 0])
        assert (widget.x(), widget.y()) == (x, y), node["name"]
        if node["type"] not in ("Label", "CheckBox", "RadioButton") and "Size" in node["props"]:
            assert (widget.width(), widget.height()) == tuple(node["props"]["Size"]), node["name"]


@pytest.fixture
def eddie(qapp, tmp_path, monkeypatch):
    """EDDIE del avance con dispositivos simulados (DeviceFactory)."""
    monkeypatch.setenv("EDDIE_DEVICE_MODE", "sim")
    messages = []
    import ui.dialogs as dialogs
    import ui.menu_settings as menu
    import ui.settings_pages as pages
    record = lambda parent, text, title="EDDIE": messages.append(text)
    for module in (dialogs, menu, pages):
        monkeypatch.setattr(module, "message", record)
    from app.runtime import EddieRuntime
    from app.settings_store import SettingsStore
    from ui.context import AppContext
    settings = SettingsStore(tmp_path / "user_settings.json")
    runtime = EddieRuntime(settings, trace_dir=tmp_path / "logs")
    runtime.start()
    ctx = AppContext(runtime=runtime, settings=settings)
    window = menu.MenuSettingsWindow(ctx)
    window.show()
    yield ctx, window, messages
    runtime.wait_for_jobs()
    window.close()
    runtime.stop()


def _settle(ctx, qapp, cycles=3):
    for _ in range(cycles):
        ctx.runtime._tick()
        ctx.runtime.wait_for_jobs()
        qapp.processEvents()


def test_integrated_plugins_start_and_only_their_pages_exist(eddie):
    ctx, window, _ = eddie
    report = ctx.runtime.orchestrator.initialization_report
    for name in ('TextCamera', 'ImageProcessor', 'ConsistencyProvider'):
        assert report[name]["status"] == "initialized", name
    assert set(ctx.pages) == set(PAGES)
    from ui.menu_settings import NAV
    for button, key in NAV.items():
        assert window.form[button].isEnabled() == (key in PAGES), button


def test_save_and_reset_text_settings_roundtrip(eddie, qapp):
    ctx, window, _ = eddie
    ctx.pages["text"].form.numericUpDownResXText.setValue(1280)
    window.save_all_settings()
    stored = json.loads(ctx.settings.path.read_text(encoding="utf-8"))
    assert stored["cameraTextWidth"] == 1280
    window.reset_all_settings()
    assert ctx.settings["cameraTextWidth"] == 640


def test_text_recognition_page_shows_the_simulated_camera(eddie, qapp):
    ctx, window, _ = eddie
    window.open_page("TextRecognitiionButton")
    _settle(ctx, qapp, 4)
    assert ctx.pages["text"].form.imageBox3.pixmap() is not None


def test_page_detection_opens_pdf_and_rejects_damaged_file(eddie, qapp, tmp_path, sample_pdf):
    ctx, window, messages = eddie
    assert ctx.pages["page"].open_pdf(str(sample_pdf))
    assert ctx.pages["page"].form.numericUpDown5.value() == 595
    damaged = tmp_path / "danado.pdf"
    damaged.write_bytes(sample_pdf.read_bytes().decode("latin-1").encode("utf-8")[:400])
    assert ctx.pages["page"].open_pdf(str(damaged)) is False
    assert messages, "debe avisar al usuario en vez de romper la aplicación"


def test_start_projection_is_announced_for_a_later_stage(eddie):
    ctx, window, messages = eddie
    window.start_projection()
    assert ctx.projection is None
    assert "P-06" in messages[-1]


def test_light_palette_keeps_text_readable(qapp):
    from PySide6.QtGui import QPalette
    palette = qapp.palette()
    assert palette.color(QPalette.ColorRole.Text).name() == "#000000"
    assert palette.color(QPalette.ColorRole.Base).name() == "#ffffff"


def test_text_page_recognizes_the_highlighted_word(eddie, qapp):
    """Text recognition muestra el rectángulo detectado y el texto reconocido (antes solo desde la proyección)."""
    ctx, window, messages = eddie
    page = ctx.pages["text"]
    window.open_page("TextRecognitiionButton")
    _settle(ctx, qapp)
    page.recognize_now()
    _settle(ctx, qapp)
    assert page.form.imageBox1.pixmap() is not None
    text = page.form.textBoxRecognized.text()
    import shutil
    if shutil.which("tesseract"):
        assert "aumentada" in text.lower()
    else:
        assert "Tesseract" in text


def test_page_detection_shows_a_preview_of_the_pdf(eddie, qapp, sample_pdf):
    ctx, window, messages = eddie
    page = ctx.pages["page"]
    assert page.open_pdf(str(sample_pdf))
    assert page.form.pdfPreview.pixmap() is not None
    assert page.form.labelPreviewPage.text() == "Página 1 / 3"
    page.show_preview(2)
    assert page.form.labelPreviewPage.text() == "Página 2 / 3"
    page.show_preview(99)                                   # fuera de rango: se queda en la última
    assert page.form.labelPreviewPage.text() == "Página 3 / 3"


def test_info_icons_and_buttons_with_help_do_not_raise(eddie, qapp, monkeypatch):
    """Regresión: clicked(bool) de los botones "Browse" llegaba como w=False a la lambda de la ayuda
    ("'bool' object has no attribute 'mapToGlobal'")."""
    import sys
    from PySide6.QtWidgets import QAbstractButton, QFileDialog
    ctx, window, messages = eddie
    errors = []
    monkeypatch.setattr(sys, "excepthook", lambda *exc: errors.append(exc[1]))
    for name in ("getExistingDirectory",):
        monkeypatch.setattr(QFileDialog, name, lambda *a, **k: "")
    for name in ("getOpenFileName", "getSaveFileName"):
        monkeypatch.setattr(QFileDialog, name, lambda *a, **k: ("", ""))
    for page in ctx.pages.values():
        for control in page.TOOLTIPS:
            widget = page.form.controls.get(control)
            if widget is None:
                continue
            if isinstance(widget, QAbstractButton):
                widget.click()                                  # emite clicked(checked=False), como el usuario
            else:
                widget.clicked.emit()
            qapp.processEvents()
    assert not errors, errors
