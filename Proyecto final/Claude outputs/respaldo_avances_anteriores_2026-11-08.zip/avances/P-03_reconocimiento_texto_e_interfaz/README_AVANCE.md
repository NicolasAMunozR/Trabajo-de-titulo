# P-03 — Reconocimiento de texto e interfaz de configuración

Parte de la serie de avances de EDDIE en Python. La guía general (metodología, requisitos, hallazgos y cómo regenerar las evidencias) está en `../GUIA_AVANCES.md`.

Fase PDCA: **Do (implementación)** · Objetivo específico: **OE3** · Semanas del plan: **9** · Carpeta: `P-03_reconocimiento_texto_e_interfaz`

| | |
|---|---|
| **ID Prototipo** | P-03 |
| **Nombre** | Reconocimiento de texto e interfaz de configuración |
| **Objetivos** | Integrar el reconocimiento del texto resaltado (IImageProcessor: segmentación del resaltado + Tesseract) sobre la cámara de texto declarada.<br>Construir la interfaz «EDDIE Menu Settings» desde los layouts extraídos de los .Designer.cs, con las páginas Text recognition y Page detection.<br>Ejecutar el ciclo del orquestador dentro de Qt (EddieRuntime) y persistir los ajustes.<br>Poder probar el OCR y ver el PDF cargado desde estas páginas, sin esperar la pantalla de proyección. |
| **Descripción** | Aparece la interfaz, idéntica al original en posición y tamaño de cada control. Solo se construyen las páginas de los módulos ya integrados: las demás secciones del menú se ven deshabilitadas con la indicación del avance en que se integran, y «Start Projection» avisa que la proyección llega en P-06. Como en el C# el texto reconocido solo se veía desde la proyección, se agregan dos controles nuevos: el botón «Recognize text» con el texto reconocido en Text recognition, y una vista previa del PDF con navegación de páginas en Page detection. |
| **Requisitos Funcionales** | FD1, N7, RFS3, RFS5, RFS6, RFS7, RFS8 |
| **Requisitos No Funcionales** | RNF-01, RNF-06, RNF-07 |

### Qué se revisa en este avance

1. Que «Recognize text» marque el resaltado amarillo en la imagen y muestre el texto leído por el OCR («aumentada» en la hoja simulada; con la cámara real, la palabra que resaltes en papel).
2. Que Page detection muestre la página del PDF cargado y permita recorrerlo.
3. Que cada control de los formularios incluidos esté en la misma posición y tamaño que en el C#.
4. Que Save/Reset Settings persistan y restauren los valores (config/user_settings.json).
5. Que Page detection abra un PDF válido y rechace uno dañado con un mensaje, sin cerrarse.
6. Capturas de Menu Settings, Text recognition y Page detection (evidencias/capturas).

### Cómo ejecutarlo

```powershell
python main.py --sim
python -m pytest
python tools\generar_evidencias.py
```

### Resultados

Ejecución en `Linux 6.18.44-fc-v233`, Python 3.13.18, dispositivos simulados, 2026-11-04 15:07:30.

| Pruebas aprobadas | Fallo esperado (hallazgo) | Fallidas | Cobertura de líneas | Ciclo completo p95 | Ciclo completo máx. |
|---|---|---|---|---|---|
| 60 | 0 | 0 | 76 % | 0,14 ms | 0,59 ms |

Plugin con mayor latencia (p95): **TextCamera**, 0,10 ms (umbral 8,3 ms). Detalle por plugin en `evidencias/RESULTADOS.md`.

Figuras disponibles para la tesis:

- `evidencias/capturas/00_menu_settings.png` — Tercer prototipo: Menú de configuración «EDDIE Menu Settings».
- `evidencias/capturas/01_text.png` — Tercer prototipo: Text recognition con la cámara de texto simulada.
- `evidencias/capturas/02_page.png` — Tercer prototipo: Page detection (selección del PDF).

Hallazgos relacionados: H-02 (ver «Hallazgos de la verificación»).

