# Interfaz renovada (P-08): qué cambió y por qué

P-08 parte de una copia de P-07. El núcleo (`orchestrator/`), los plugins, los contratos, la configuración y la lógica de cada pantalla no cambian. Lo que cambia es **la capa visual** y algunos **flujos de uso** que el diseño anterior hacía más lentos. En P-07 la interfaz reproducía al píxel los `.Designer.cs` de EDDIE-2023 (RNF-06). En P-08 ese requisito se reemplaza por RNF-09: se conservan los mismos controles y flujos, con otro diseño.

Las comparaciones lado a lado (P-07 a la izquierda, P-08 a la derecha) están en `docs/comparacion_interfaz/`.

## 1. Cómo se cambió el diseño sin tocar la lógica

La lógica accede a cada control por su nombre (`self.form.rbtn_voz_si`, `self.form.btn_diccionario`…). Por eso el cambio se hizo en el **constructor** de pantallas, sin reescribir las páginas:

| | P-07 | P-08 |
|---|---|---|
| Constructor | `ui/form_builder.build_form`: crea cada control en la posición y con el tamaño del `.Designer.cs` | `ui/modern_forms.build_modern`: crea **los mismos controles, con el mismo nombre y comportamiento** (rangos, valores, ítems y estados de los JSON), y los ordena con layouts de Qt |
| Aspecto | Colores, fuentes e imágenes PNG del original | Sistema visual propio (`ui/theme.py`) e iconos vectoriales Lucide (licencia ISC, `ui/resources/icons`) |
| Controles nuevos de la lógica | Posiciones fijas (`setGeometry`) | Ranuras del diseño (`form.place("recognition", …)`) |
| Textos | Inglés y español mezclados | Español en toda la interfaz |

Los controles del original que el diseño ya no muestra (rótulos de unidades, paneles decorativos, el GIF de carga, las líneas guía) siguen existiendo en un contenedor oculto (`form.spare`), así que ninguna referencia de la lógica queda rota. La prueba `test_every_original_control_exists_in_the_new_interface` revisa, en los 11 formularios, que cada control del original exista con un tipo compatible, el mismo rango y valor inicial y el mismo estado de habilitación.

Archivos de la capa visual:

- `ui/theme.py`: colores, tipografía, hoja de estilo (QSS) de la ventana y de la proyección, e iconos.
- `ui/widgets.py`: controles propios. `ActionButton` (variantes de botón), `NavButton` (menú con estado), `ToolButton` (botón proyectado con estado y progreso de la mirada), `FitFrameView` (cámara sin deformar), `Spinner`, tarjetas y selectores segmentados.
- `ui/modern_forms.py`: cómo se ordena cada pantalla.

## 2. Ventana de configuración

| Antes (P-07) | Ahora (P-08) | Por qué |
|---|---|---|
| Al abrir, un panel vacío | **Preparar sesión**: seis pasos numerados (PDF, cámara de texto, proveedor LLM, gesto, eye tracker, voz) con su estado real y un botón a cada página | El lector o el investigador ve qué falta antes de proyectar. Los pasos son una secuencia real de preparación, por eso van numerados |
| Menú de texto | Menú lateral con icono y un **punto de estado** por módulo (verde listo, ámbar pendiente, gris opcional o apagado) | El estado de los plugins (`initialization_report`) ya existía, pero solo se veía en el log |
| — | Al pie del menú: plugins activos y **duración media del ciclo** del orquestador | Hace visible el RNF-01 durante el uso |
| Título «EDDIE Menu Settings» en una barra celeste | Barra lateral en azul tinta; el área de trabajo usa tarjetas con título, ayuda y una línea que explica para qué sirve cada opción | Las ayudas del original solo aparecían al pasar el mouse por un icono |
| «Save Settings» abría un cuadro que había que cerrar | **Guardar** confirma con un aviso que se cierra solo | Un paso menos |
| `MessageBox` modal para cada mensaje | **Avisos no modales** apilados en la esquina (rojo oscuro si es un problema); se cierran solos o con un clic | En la proyección un cuadro modal detenía la lectura hasta pulsar «Aceptar» |
| Imagen de cámara estirada al tamaño del control | La imagen conserva su proporción (`FitFrameView`) y hay un texto cuando aún no hay imagen | El original deformaba los 4:3 de la cámara a 16:9 |
| Calibración gestual: leer «Sensor X/Y» y escribirlo en cuatro campos | **Fijar inicio** / **Fijar fin** copian la lectura actual del sensor; la tabla de calibración queda por ejes (X, Y) | Calibrar era la tarea más propensa a errores de transcripción |
| Interacción y servicios sin indicar si funcionan | «Reconocedor listo» o «no disponible»; lista de proveedores LLM con su estado («revisa la clave en config/secrets.json») | La falta de clave de Gemini solo se notaba al buscar |
| Radios Yes/No | Selectores segmentados («Activados / Desactivados», «Visibles / Ocultos») | Se lee de un vistazo cuál está elegido |

## 3. Pantalla proyectada

La proyección se diseñó con tres hallazgos de la evaluación de Ibaceta (2023) sobre EDDIE-2023:

1. **El eye tracker tuvo validez del 100 % en la zona superior** de la proyección y baja en la zona inferior y central. Por eso **todos los botones pasan a la franja superior**: una primera fila con Historial, Modo, Buscar, Sincronizar PDF y Salir, y una segunda fila con los servicios o las herramientas del PDF. La franja inferior central, donde antes estaban Web Searcher, Highlight mode y Synchronizer, queda libre.
2. **El botón de resaltado era amarillo, del mismo color que el resaltador**, y confundía al OCR. En P-08 **ningún color de la interfaz es amarillo**: el amarillo queda solo para el resaltado que busca la cámara. El acento es un verde azulado. La prueba `test_interface_chrome_never_uses_yellow` revisa todos los colores del sistema visual.
3. **La zona de lectura y las cruces de calibración no se mueven** (HighlightTool en 285, 65 de 517 × 400; cruces en 298, 20 · 297, 570 · 797, 570). De ellas dependen el montaje del proyector y la calibración gestual ya hecha. Lo prueba `test_projection_keeps_reading_area_and_moves_buttons_to_the_upper_band`.

Otros cambios:

| Antes (P-07) | Ahora (P-08) | Por qué |
|---|---|---|
| Fondo lila claro en toda la proyección | **Fondo negro**: el proyector no emite luz donde no hay contenido; solo se iluminan la zona de lectura y los paneles de resultado | Menos luz sobre el escritorio y el borde del libro, y los resultados se distinguen como notas sobre la mesa |
| Cruces azul oscuro | Cruces claras dibujadas | Sobre negro las originales no se verían |
| El botón de modo mostraba la imagen del modo **al que se cambiaba** | Dice el **modo actual**: «Capturando» o «Resaltando» (encendido) | Elimina la ambigüedad del original |
| Web Searcher y Synchronizer cambiaban de imagen ON/OFF | Botones con estado **encendido**; el servicio que respondió queda marcado | Reemplaza las líneas guía que conectaban el resultado con su botón |
| — | Si el control por mirada está activo, una **barra se llena** en el botón mientras se lo mira | El lector sabe cuándo se hará el clic por permanencia |
| Herramientas del PDF dispersas abajo a la derecha | Tarjeta **Sincronización con el PDF** (página sincronizada, búsqueda, resultado) y botones papel → PDF / PDF → papel en la segunda fila | Un solo lugar, con un panel por lado: al abrir el sincronizador se cierra el panel de resultados derecho |
| Historial con fecha, término y servicio en cajas | Tarjetas con el término destacado, el servicio y la hora | Se encuentra la búsqueda por el término |
| GIF «Loading…» | Píldora «Buscando…» junto al panel donde aparecerá el resultado | Más liviana y no tapa el libro |

## 4. Lo que no cambió

- Todas las funciones y su orden: resaltar → OCR → corregir el término → buscar (5 servicios) → leer en voz alta → historial y CSV; modo captura → búsqueda por imagen; sincronizar resaltados, marcadores, comentarios y figuras en ambos sentidos; comandos de voz; eye tracking con retícula, clic por mirada y CSV; exportar e importar la configuración de eye tracking; guardar y restaurar ajustes.
- Las claves de `config/user_settings.json`, el formato del CSV de actividades y el de la configuración exportada de eye tracking.
- Los mensajes que dependen de la lógica, traducidos donde estaban en inglés (por ejemplo, «Make sure you upload a pdf file.» pasa a «Primero elige el PDF del libro en «Documento PDF».»).

## 5. Verificación

- 107 pruebas: las 98 de P-07, de las que dos se ajustan solo por la traducción de un texto y la de geometría se reemplaza por la de controles, más 9 nuevas en `tests/test_avance_p08.py`.
- Las nuevas cubren: sin amarillo, la zona de lectura fija y los botones arriba, el modo actual, el servicio marcado, la tarjeta del PDF con un panel por lado, los avisos no modales, «Preparar sesión» con el estado real, «Fijar inicio/fin» y el estado del sistema.
- `tools/generar_evidencias.py` agrega tres capturas de la proyección en uso: `11_proyeccion_busqueda`, `12_proyeccion_pdf` y `13_proyeccion_historial`. Las respuestas que aparecen en ellas las da el LLM local de prueba de `tests/conftest.py`, no Gemini.
- Pendiente para la tesis: validar el fondo negro y la franja superior con lectores y con el eye tracker en el laboratorio (MECIVA PS). Las razones de diseño anteriores son hipótesis basadas en Ibaceta (2023), no resultados medidos con P-08.
