# Resultados — P-08_interfaz_renovada

Generado: 2026-11-06T18:45:10 · Python 3.13.18 · Linux 6.18.44-fc-v242 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 107 | 0 | 0 | 0 | 81 % | cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz). Gesto activo durante la medición: ColorPenRecognition.

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.126 | 0.171 | 2.054 | 0 |
| GestureCamera | 0.291 | 0.373 | 2.267 | 0 |
| ImageProcessor | 0.0061 | 0.008 | 0.059 | 0 |
| ColorPenRecognition | 0.1222 | 0.861 | 3.165 | 0 |
| HandSkinRecognition | 0.0031 | 0.005 | 0.153 | 0 |
| MouseRecognition | 0.0023 | 0.003 | 0.071 | 0 |
| EyeTrackerMock | 0.01 | 0.012 | 0.101 | 0 |
| SpeechProvider | 0.0032 | 0.004 | 0.059 | 0 |
| GazeSession | 0.0046 | 0.006 | 0.056 | 0 |
| ConsistencyProvider | 0.0086 | 0.011 | 0.099 | 0 |
| **Ciclo completo** | 0.6249 | 1.3934 | 9.6173 | 1 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| GestureCamera | initialized |  |
| ImageProcessor | initialized |  |
| ColorPenRecognition | initialized |  |
| HandSkinRecognition | initialized |  |
| MouseRecognition | initialized |  |
| EyeTracker-GazePoint | disabled |  |
| EyeTracker-EyeTribe | disabled |  |
| EyeTracker-GazeCloud | disabled |  |
| EyeTrackerMock | initialized |  |
| GazeSession | initialized |  |
| ConsistencyProvider | initialized |  |
| LLM-Gemini | initialization_failed | initialize() retornó False. |
| SpeechProvider | initialized |  |

## Demostración de consistencia papel ↔ PDF (demos/demo_consistencia.py)

| Llamada (por OrchestratorCore.invoke) | Correcta | Latencia (ms) | Resultado |
|---|---|---|---|
| search_text | sí | 5.77 | [2] |
| add_highlight | sí | 3.212 | True |
| add_bookmark | sí | 2.552 | None |
| sync_bookmark_from_frame | sí | 10.153 | True |
| sync_comments_from_frame | sí | 10.936 | 1 |
| sync_figures_from_frame | sí | 7.775 | 2 |
| get_bookmarks | sí | 0.217 | ['Introducción Pag.1', 'Marcador físico página 2 Pag.2'] |
| get_comments | sí | 0.678 | [{'content': 'Comentario físico 1 (pág. 2)', 'page': 2, 'x': |
| get_figures | sí | 0.245 | {'rectangulos': [{'x': 234.327731092437, 'y': 108.2155603694 |
| search_text | sí | 0.004 | [] |

Al reabrir el PDF guardado: anotaciones por página [1, 1, 2] (esperado [1, 1, 2]), 2 marcadores (esperado 2), PDF reparado al abrir: False. **Se conservan todos los cambios.**

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
- capturas/03_gesture_mano.png
- capturas/03_gesture_lapiz.png
- capturas/04_eye.png
- capturas/05_web.png
- capturas/06_interactions.png
- capturas/10_proyeccion.png
- capturas/11_proyeccion_busqueda.png
- capturas/12_proyeccion_pdf.png
- capturas/13_proyeccion_historial.png
