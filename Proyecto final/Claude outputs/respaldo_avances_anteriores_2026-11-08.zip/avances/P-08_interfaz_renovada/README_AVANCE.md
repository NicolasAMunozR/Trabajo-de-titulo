# P-08 — Interfaz renovada

Parte de la serie de avances de EDDIE en Python. La guía general (metodología, requisitos, hallazgos y cómo regenerar las evidencias) está en `../GUIA_AVANCES.md`.

Fase PDCA: **Act (mejora)** · Objetivo específico: **OE4** · Semanas del plan: **18 (adicional)** · Carpeta: `P-08_interfaz_renovada`

| | |
|---|---|
| **ID Prototipo** | P-08 |
| **Nombre** | Interfaz renovada |
| **Objetivos** | Rediseñar la capa visual de la ventana de configuración y de la proyección sin cambiar el núcleo, los plugins ni la lógica de las pantallas.<br>Aplicar a la proyección los hallazgos de Ibaceta (2023): botones en la zona superior y ningún botón amarillo.<br>Acortar flujos: preparación de la sesión, calibración gestual asistida y avisos no modales. |
| **Descripción** | Copia de P-07 con un constructor de pantallas nuevo (ui/modern_forms.py) que crea los mismos controles del original y los ordena con layouts, un sistema visual propio (ui/theme.py) y la interfaz en español. La zona de lectura y las cruces de calibración quedan en la misma posición. No se integra en «Proyecto final». |
| **Requisitos Funcionales** | U1, U2, U3, RFS1, RFS2, RFS3, RFS4, RFS5 |
| **Requisitos No Funcionales** | RNF-01, RNF-02, RNF-03, RNF-04, RNF-05, RNF-07, RNF-08, RNF-09 |

### Qué se revisa en este avance

1. Las 107 pruebas: las de P-07 (con la de geometría reemplazada por la de controles del original) y las 9 de tests/test_avance_p08.py.
2. «Preparar sesión»: el estado de cada paso cambia al cargar el PDF o iniciar un gesto.
3. Proyección: zona de lectura y cruces en la misma posición que P-07; botones en la franja superior; modo actual, servicio que respondió y sincronizador con su tarjeta.
4. Gestos: «Fijar inicio» y «Fijar fin» copian la lectura del sensor a la calibración.
5. Comparación lado a lado con P-07 en docs/comparacion_interfaz/ y justificación en docs/DISENO_INTERFAZ.md.
6. Pendiente en el laboratorio: validar con lectores y con el eye tracker el fondo negro y la franja superior (MECIVA PS).

### Cómo ejecutarlo

```powershell
python main.py
python main.py --sim
python -m pytest
python tools\generar_evidencias.py  [--real]
```

### Resultados

Ejecución en `Linux 6.18.44-fc-v242`, Python 3.13.18, dispositivos simulados, 2026-11-06 18:45:10.

| Pruebas aprobadas | Fallo esperado (hallazgo) | Fallidas | Cobertura de líneas | Ciclo completo p95 | Ciclo completo máx. |
|---|---|---|---|---|---|
| 107 | 0 | 0 | 81 % | 1,39 ms | 9,62 ms |

Plugin con mayor latencia (p95): **ColorPenRecognition**, 0,86 ms (umbral 8,3 ms). Detalle por plugin en `evidencias/RESULTADOS.md`.

No se inicializó **LLM-Gemini** (initialization_failed): en la máquina donde se generó no había clave de Gemini; en tu PC se carga desde config/secrets.json o GEMINI_API_KEY.

Figuras disponibles para la tesis:

- `evidencias/capturas/00_menu_settings.png` — Octavo prototipo: Ventana principal con «Preparar sesión» y el estado de cada módulo.
- `evidencias/capturas/01_text.png` — Octavo prototipo: Texto (OCR) con la cámara simulada y el texto reconocido.
- `evidencias/capturas/02_page.png` — Octavo prototipo: Documento PDF con la vista previa.
- `evidencias/capturas/03_gesture_mano.png` — Octavo prototipo: Gestos con Hand Skin (mano).
- `evidencias/capturas/03_gesture_lapiz.png` — Octavo prototipo: Gestos con Color Pen (lápiz).
- `evidencias/capturas/04_eye.png` — Octavo prototipo: Rastreo ocular.
- `evidencias/capturas/05_web.png` — Octavo prototipo: Búsquedas (proveedor LLM y servicio por tipo).
- `evidencias/capturas/06_interactions.png` — Octavo prototipo: Interacción (voz y botones).
- `evidencias/capturas/10_proyeccion.png` — Octavo prototipo: Pantalla de proyección renovada.
- `evidencias/capturas/11_proyeccion_busqueda.png` — Octavo prototipo: Proyección con definición y enciclopedia (LLM local de prueba).
- `evidencias/capturas/12_proyeccion_pdf.png` — Octavo prototipo: Proyección con el sincronizador del PDF.
- `evidencias/capturas/13_proyeccion_historial.png` — Octavo prototipo: Proyección con el historial de búsquedas.

Demostración de consistencia (`evidencias/consistencia/`): 10/10 llamadas correctas. Al reabrir el PDF: anotaciones por página [1, 1, 2] (esperado [1, 1, 2]), 2 marcadores. Se conserva todo.

