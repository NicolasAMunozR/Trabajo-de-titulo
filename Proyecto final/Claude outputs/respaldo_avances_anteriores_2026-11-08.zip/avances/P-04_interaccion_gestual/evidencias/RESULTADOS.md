# Resultados — P-04_interaccion_gestual

Generado: 2026-11-04T15:07:39 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 73 | 0 | 0 | 1 | 78 % | no cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz). Gesto activo durante la medición: ColorPenRecognition.

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0805 | 0.113 | 0.367 | 0 |
| GestureCamera | 0.1663 | 0.245 | 1.731 | 0 |
| ImageProcessor | 0.0047 | 0.006 | 0.07 | 0 |
| ColorPenRecognition | 0.0997 | 0.746 | 1.444 | 0 |
| HandSkinRecognition | 0.0021 | 0.004 | 0.056 | 0 |
| MouseRecognition | 0.0019 | 0.002 | 0.031 | 0 |
| ConsistencyProvider | 0.0082 | 0.01 | 0.078 | 0 |
| **Ciclo completo** | 0.3969 | 1.0433 | 2.165 | 0 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| GestureCamera | initialized |  |
| ImageProcessor | initialized |  |
| ColorPenRecognition | initialized |  |
| HandSkinRecognition | initialized |  |
| MouseRecognition | initialized |  |
| ConsistencyProvider | initialized |  |

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
- capturas/03_gesture_mano.png
- capturas/03_gesture_lapiz.png
