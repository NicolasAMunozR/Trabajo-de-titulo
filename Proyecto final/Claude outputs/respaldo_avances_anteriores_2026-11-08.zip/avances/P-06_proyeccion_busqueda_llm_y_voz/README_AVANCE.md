# P-06 — Pantalla de proyección, búsqueda con LLM y voz

Parte de la serie de avances de EDDIE en Python. La guía general (metodología, requisitos, hallazgos y cómo regenerar las evidencias) está en `../GUIA_AVANCES.md`.

Fase PDCA: **Do (implementación)** · Objetivo específico: **OE3** · Semanas del plan: **12** · Carpeta: `P-06_proyeccion_busqueda_llm_y_voz`

| | |
|---|---|
| **ID Prototipo** | P-06 |
| **Nombre** | Pantalla de proyección, búsqueda con LLM y voz |
| **Objetivos** | Integrar la pantalla de proyección (ProjectionScreenActivity2): modo resaltado, Web Searcher, Synchronizer y herramientas papel↔PDF.<br>Responder los cinco servicios de búsqueda con Gemini 2.5 Flash bajo IWebSearchProvider, en lugar de las APIs vencidas (Wikipedia, Google, Bing, YouTube, Cloud Vision).<br>Integrar lectura en voz alta y comandos de voz (ISpeechProvider) y las páginas Interactions WS y Web search services. |
| **Descripción** | Con este avance el sistema queda completo y equivale al código de «Proyecto final» antes de la verificación. Es una extensión respecto del alcance del seminario, donde IWebSearchProvider quedaba solo como interfaz. |
| **Requisitos Funcionales** | B1–B13, C5, C6, C8, C11, C12, RFS1, RFS2 |
| **Requisitos No Funcionales** | RNF-01, RNF-06, RNF-08 |

### Qué se revisa en este avance

1. Flujo completo: resaltar → OCR → corregir en Captured content → diccionario/enciclopedia (LLM local falso en las pruebas) → historial CSV.
2. Búsqueda por imagen con la captura del gesto.
3. Sincronizar un resaltado de la proyección con el PDF y buscar páginas.
4. Mensajes originales cuando falta el término, la imagen o el PDF.

### Cómo ejecutarlo

```powershell
python main.py --sim
python -m pytest
python tools\generar_evidencias.py
```

### Resultados

Ejecución en `Linux 6.18.44-fc-v233`, Python 3.13.18, dispositivos simulados, 2026-11-04 15:08:05.

| Pruebas aprobadas | Fallo esperado (hallazgo) | Fallidas | Cobertura de líneas | Ciclo completo p95 | Ciclo completo máx. |
|---|---|---|---|---|---|
| 91 | 2 | 0 | 82 % | 1,04 ms | 9,01 ms |

Plugin con mayor latencia (p95): **ColorPenRecognition**, 0,71 ms (umbral 8,3 ms). Detalle por plugin en `evidencias/RESULTADOS.md`.

No se inicializó **LLM-Gemini** (initialization_failed): en la máquina donde se generó no había clave de Gemini; en tu PC se carga desde config/secrets.json o GEMINI_API_KEY.

Figuras disponibles para la tesis:

- `evidencias/capturas/00_menu_settings.png` — Sexto prototipo: Menú de configuración «EDDIE Menu Settings».
- `evidencias/capturas/01_text.png` — Sexto prototipo: Text recognition con la cámara de texto simulada.
- `evidencias/capturas/02_page.png` — Sexto prototipo: Page detection (selección del PDF).
- `evidencias/capturas/03_gesture_mano.png` — Sexto prototipo: Gesture recognition con Hand Skin (mano).
- `evidencias/capturas/03_gesture_lapiz.png` — Sexto prototipo: Gesture recognition con Color Pen (lápiz).
- `evidencias/capturas/04_eye.png` — Sexto prototipo: Eye tracking.
- `evidencias/capturas/05_web.png` — Sexto prototipo: Web search services (proveedor LLM).
- `evidencias/capturas/06_interactions.png` — Sexto prototipo: Interactions WS.
- `evidencias/capturas/10_proyeccion.png` — Sexto prototipo: Pantalla de proyección.

Hallazgos relacionados: H-01, H-02 (ver «Hallazgos de la verificación»).

