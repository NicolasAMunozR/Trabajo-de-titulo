# Resultados — P-06_proyeccion_busqueda_llm_y_voz

Generado: 2026-11-04T15:08:05 · Python 3.13.18 · Linux 6.18.44-fc-v233 · dispositivos simulado

## Pruebas automatizadas

| Aprobadas | Fallidas | Omitidas | Fallo esperado (hallazgo documentado) | Cobertura de líneas | Umbral 80 % |
|---|---|---|---|---|---|
| 91 | 0 | 0 | 2 | 82 % | cumple |

## Latencia del OrchestratorCore

500 ciclos medidos (tras 10 de calentamiento). Objetivo por plugin: ≤ 8.3 ms (50 % de una muestra a 60 Hz). Gesto activo durante la medición: ColorPenRecognition.

| Plugin | Media (ms) | p95 (ms) | Máx. (ms) | Ciclos > 8,3 ms |
|---|---|---|---|---|
| TextCamera | 0.0958 | 0.114 | 8.652 | 1 |
| GestureCamera | 0.1612 | 0.239 | 0.63 | 0 |
| ImageProcessor | 0.0045 | 0.006 | 0.084 | 0 |
| ColorPenRecognition | 0.0941 | 0.708 | 1.456 | 0 |
| HandSkinRecognition | 0.0022 | 0.004 | 0.036 | 0 |
| MouseRecognition | 0.002 | 0.002 | 0.027 | 0 |
| EyeTrackerMock | 0.0081 | 0.013 | 0.07 | 0 |
| SpeechProvider | 0.0023 | 0.003 | 0.011 | 0 |
| GazeSession | 0.004 | 0.005 | 0.086 | 0 |
| ConsistencyProvider | 0.0082 | 0.01 | 0.096 | 0 |
| **Ciclo completo** | 0.4226 | 1.0359 | 9.012 | 1 |

## Carga de plugins

| Plugin | Estado | Detalle |
|---|---|---|
| TextCamera | initialized |  |
| GestureCamera | initialized |  |
| ImageProcessor | initialized |  |
| ColorPenRecognition | initialized |  |
| HandSkinRecognition | initialized |  |
| MouseRecognition | initialized |  |
| EyeTracker-GazePoint | disabled |  |
| EyeTracker-EyeTribe | disabled |  |
| EyeTracker-GazeCloud | disabled |  |
| EyeTrackerMock | initialized |  |
| GazeSession | initialized |  |
| ConsistencyProvider | initialized |  |
| LLM-Gemini | initialization_failed | initialize() retornó False. |
| SpeechProvider | initialized |  |

## Capturas

- capturas/00_menu_settings.png
- capturas/01_text.png
- capturas/02_page.png
- capturas/03_gesture_mano.png
- capturas/03_gesture_lapiz.png
- capturas/04_eye.png
- capturas/05_web.png
- capturas/06_interactions.png
- capturas/10_proyeccion.png
